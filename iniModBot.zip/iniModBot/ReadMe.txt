    Copyright (C) 2012  Michael W. Wernicki

    michael@wernicki.com

    Michael W. Wernicki
    P.O. Box 1284
    Secaucus, NJ 07096-1284

The source code is written using Visual Prolog. Their noncommercial version of the compiler is free with registration. The attached work was generated with the commercial version. One of the DLL is only available with the commercial version. 

It is possible to write the application without the commercial DLL. Further, the application could be written with a free prolog compiler. 



							Advantages

There are several advantages to using the application. 

You can use the "Move Up" and "Move Down" button to change the order of the different spells/alias. The application will place the correctly number the ModBot variables given the order in the list. It is usually easy to get a number wrong doing it by hand. The result is a default is used which might not provide the desired results. 

The information is organized in easy to understand groups. 

There is not going to be any missing on misspelled ModBot variables.

The count for a section is automatically generated. You will need to generate the initialization file and edit it manually to change the count. Of course, you could generate profiles with only the required number of alias.

The macro section will automatically number the lines. Take care not to have an extra line. It will number a blank line and add it to the count.


							Instructions

The compiled code has been included in the EXE subdirectory. Place the files there in a convenient location. Execute the inimodbot file. A team.dbs file example database has been included. It contains the ModBot initialization file of a number of characters. Load it i.e. use "File", "Open", team.dbs. The tabs have been organized to reflect the initialization groupings in ModBot. If you are not familiar with these groupings see the ModBot documentation.

At the bottom of the first tab is a list of profiles. Load a profile by double clicking on it. You will notice the field above the list box contains the name of the profile. When you save, you save against the name in the field. Warning! If the list box has the same name it will be overwritten. There will be no warning.

double click	load	the profile of the character.
single click 	select	This is useful when you insert. It will insert at the selected location.
		delete	This deletes the selected item in the list box
		save	Save the profile in the field above the list box. Overwrites any profile with the same name.
		new	Clear the profile  
		
		
If you go to the AdvHeal tab, you will seem a similar list box at the bottom. The box contains all the different alias. There cannot be a duplicate. Again, there is a field above the list box. It will be loaded with the alias you double click and in the list box. You can also just type in the field. In general, it acts similar to the tab with the profiles. In addition it has the following:

		move up		Move the alias up in the list.
		move down	Move the alias down in the list.

The generate tab generates the initialization file. Select the all the text using standard editor commands. You can now paste the clipboard information to any file to create an initialization file. 

Usually, you will need to do 3 saves before exiting the application.
	1. Save the alias.
	2. Save the profile.
	3. Save the database with a "File" and "Save".
